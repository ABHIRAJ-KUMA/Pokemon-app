(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_f60b25c4._.js",
  "static/chunks/src_app_details_page_7a4dd75b.js"
],
    source: "dynamic"
});
